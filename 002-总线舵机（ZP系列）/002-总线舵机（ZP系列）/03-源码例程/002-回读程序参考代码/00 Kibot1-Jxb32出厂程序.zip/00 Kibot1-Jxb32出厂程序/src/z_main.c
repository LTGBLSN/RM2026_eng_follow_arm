/***************************************************************
	@笔者：tacbo
	@日期：2017年11月08日
	@所属：杭州众灵科技有限公司
	@功能：实现舵机控制器功能
	功能列表： 实现总线舵机串口收发功能 定时1S读位置
	总线接口为串口3 stm32的串口有单总线功能，我们这里用的是单总线回读做的
	硬件基于 STM32六路舵机控制板

***************************************************************/

#include "z_rcc.h"			//配置时钟文件
#include "z_gpio.h"		//配置IO口文件
#include "z_global.h"	//存放全局变量
#include "z_delay.h"		//存放延时函数
#include "z_type.h"		//存放类型定义
#include "z_usart.h"		//存放串口功能文件
#include "z_timer.h"
#include <stdio.h>			//标准库文件
#include <string.h>		  //标准库文件
#include <math.h>			  //标准库文件


void setup_rcc(void);
void setup_global(void);
void setup_gpio(void);
void setup_nled(void);
void setup_beep(void);
void setup_systick(void);
void setup_uart1(void);
void setup_uart2(void);
void setup_uart3(void);
void setup_start(void);
void setup_interrupt(void);
void setup_zx_servo(void);

void loop_nled(void);
void loop_uart(void);
void loop_read(void);


/*-------------------------------------------------------------------------------------------------------
*  程序从这里执行				
*  这个启动代码 完成时钟配置 使用外部晶振作为STM32的运行时钟 并倍频到72M最快的执行速率
-------------------------------------------------------------------------------------------------------*/
u16 csb_t = 0;
int main(void) {	
	setup_rcc();			//初始化时钟
	setup_global();		//初始化全局变量
	setup_gpio();			//初始化IO口
	setup_nled();			//初始化工作指示灯
	setup_beep();			//初始化定时器

	setup_uart1();		//初始化串口1
	setup_uart2();		//初始化串口2
	setup_uart3();		//初始化串口3
	
	setup_systick();

	setup_interrupt();	//初始化总中断	
	setup_start();		//初始化启动信号
	setup_zx_servo();	//总线舵机初始化运动
		
	while(1) {
		loop_nled();		       	//循环执行工作指示灯，500ms跳动一次 和声音公用一个IO口 这里在声音功能启用的时候就关闭nled
		loop_uart();		       	//串口数据接收处理
		loop_read();				//循环读取数据
	}
}

//--------------------------------------------------------------------------------
/*
	初始化函数实现
*/




void setup_rcc(void) {   //初始化时钟
	tb_rcc_init();	  	   //时钟初始化
}

void setup_global(void) {//初始化全局变量
	tb_global_init();	
}

void setup_gpio(void) { //初始化IO口
	tb_gpio_init();		    
}

void setup_nled(void) { //初始化工作指示灯
	nled_init();		
	nled_off();		        //工作指示灯关闭
}

void setup_beep(void) { //初始化定时器蜂鸣器
	beep_init();		
	beep_off();			      //关闭蜂鸣器
}	

//初始化滴答时钟，1S增加一次millis()的值
void setup_systick(void) {
	//系统滴答时钟初始化	
	SysTick_Int_Init();
}	

void setup_uart1(void) {
  //串口1初始化
	tb_usart1_init(115200);
	//串口1打开
	uart1_open();
	//串口发送测试字符
	uart1_send_str((u8 *)"uart1 check ok!");
}
//初始化串口2
void setup_uart2(void) {
	//串口2初始化
	tb_usart2_init(115200);
	//串口2打开
	uart2_open();
	//串口发送测试字符
	uart2_send_str((u8 *)"uart2 check ok!");
}	
//初始化串口3
void setup_uart3(void) {
	//串口3初始化
	tb_usart3_init(115200);
	//串口3打开
	uart3_open();
	//串口发送测试字符
	uart3_send_str((u8 *)"uart3 check ok!");
	
	//总线输出 复位总线舵机 串口3即为总线串口
	zx_uart_send_str((u8 *)"#255P1500T2000!");
}	

//初始化启动信号
void setup_start(void) {
	//蜂鸣器LED 名叫闪烁 示意系统启动
	beep_on();nled_on();tb_delay_ms(100);beep_off();nled_off();tb_delay_ms(100);
	beep_on();nled_on();tb_delay_ms(100);beep_off();nled_off();tb_delay_ms(100);
	beep_on();nled_on();tb_delay_ms(100);beep_off();nled_off();tb_delay_ms(100);
}	

//初始化总中断
void setup_interrupt(void) {
	//总中断打开
	tb_interrupt_open();
}	

void setup_zx_servo(void) {//开机动作测试舵机
    static int index = 0, pwmv = 1500, timev = 0;
    index = 0; pwmv = 1700;timev = 200;
    sprintf(cmd_return, ">>>#%03dP%04dT%04d!", index, pwmv, timev);
    zx_uart_send_str(cmd_return);
    mdelay(1000);

    index = 0; pwmv = 1300;timev = 200;
    sprintf(cmd_return, ">>>#%03dP%04dT%04d!", index, pwmv, timev);
    zx_uart_send_str(cmd_return);
    mdelay(1000);

    index = 0; pwmv = 1500;timev = 200;
    sprintf(cmd_return, ">>>#%03dP%04dT%04d!", index, pwmv, timev);
    zx_uart_send_str(cmd_return);
    mdelay(1000);

    zx_uart_send_str("#000PULK!");mdelay(10);
    zx_uart_send_str("#000PULM!");
}
//--------------------------------------------------------------------------------


//--------------------------------------------------------------------------------
/*
	主循环函数实现
*/
//循环执行工作指示灯，500ms跳动一次
void loop_nled(void) {
	static u32 time_count=0;
	static u8 flag = 0;
	if(millis()-time_count > 1000)  {
		time_count = millis();
		if(flag) {
			nled_on();
		} else {
			nled_off();
		}
		flag= ~flag;
	}
}		
//串口数据接收处理
void loop_uart(void) {
	int index, pwmv;
	if(uart1_get_ok) {
		uart1_send_str(uart_receive_buf);
		if(uart1_mode == 1) {					//命令模式
			//uart1_send_str("cmd:");
			//uart1_send_str(uart_receive_buf);
		} else if(uart1_mode == 2) {			//单个舵机调试
			if(uart_receive_buf[0] =='#' && uart_receive_buf[4] =='P' && uart_receive_buf[9] =='!') {
                index = (uart_receive_buf[1] - '0')*100 +  (uart_receive_buf[2] - '0')*10 +  (uart_receive_buf[3] - '0')*1;
                pwmv =  (uart_receive_buf[5] - '0')*1000 + (uart_receive_buf[6] - '0')*100 +  (uart_receive_buf[7] - '0')*10 +  (uart_receive_buf[8] - '0')*1;
                sprintf(cmd_return, "index = %03d  pwmv = %04d", index, pwmv);
                uart1_send_str(cmd_return);
            }
		} else if(uart1_mode == 3) {		//多路舵机调试
			//uart1_send_str("group:");
			
			

		} else if(uart1_mode == 4) {		//存储模式
			//uart1_send_str("save:");
			//uart1_send_str(uart_receive_buf);
		} 
		uart1_mode = 0;
		uart1_get_ok = 0;
		uart1_open();
	}
	return;
}	


void loop_read(void) {
   static long long systick_ms_bak = 0;

   //循环发送角度
   if(millis() - systick_ms_bak > 1000) {
      systick_ms_bak = millis();
      zx_uart_send_str("#000PRAD!");
   }
}



