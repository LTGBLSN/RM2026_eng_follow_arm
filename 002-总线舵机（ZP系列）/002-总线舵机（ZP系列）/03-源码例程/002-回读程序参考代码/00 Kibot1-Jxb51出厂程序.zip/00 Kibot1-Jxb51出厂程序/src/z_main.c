/*
	@笔者：tacbo
	@日期：2017年11月08日
	@所属：杭州众灵科技有限公司
	@功能：实现舵机控制器功能
	功能列表： 实现总线舵机串口收发功能 定时1S读位置
	总线接口为串口3 stm32的串口有单总线功能，我们这里用的是单总线回读做的
	硬件基于 51六路舵机控制板
	
*/

#include <stdio.h>
#include <string.h>
#include <intrins.h>
#include "z_stc15.h"
#include "z_main.h"
#include "z_uart.h"
#include "z_delay.h"
#include "z_gpio.h"
#include "z_timer.h"
#include "z_global.h"

/*
	代码从main里开始执行
	在进入大循环while(1)之前都为各个模块的初始化
	最后在大循环处理持续执行的事情
	另外注意uart中的串口中断，接收数据处理
	timer中的定时器中断，舵机的脉冲收发就在那里
*/


void setup_global(void);
void setup_gpio(void);
void setup_nled(void);
void setup_beep(void);
void setup_systick(void);
void setup_uart1(void);
void setup_uart2(void);
void setup_uart3(void);
void setup_start(void);
void setup_interrupt(void);
void setup_zx_servo(void);

void loop_nled(void);
void loop_uart(void);
void loop_read(void);


void main(void) {
	
	setup_global();			//初始化全局变量
	setup_gpio();			//初始化IO口
	setup_nled();			//初始化工作指示灯
	setup_beep();			//初始化定时器

	setup_uart1();			//初始化串口1
	setup_uart2();			//初始化串口2
	setup_uart4();			//初始化串口4
	
	setup_systick();		//初始化滴答时钟，1S增加一次systick_ms的值
	setup_interrupt();		//初始化总中断
	
	setup_start();			//初始化启动信号
	
	setup_zx_servo();	//总线舵机初始化运动
	
    while (1) {
		loop_nled();			//循环执行工作指示灯，500ms跳动一次.
		loop_uart();			//串口数据接收处理
		loop_read();
	}
}

//--------------------------------------------------------------------------------
/*
	初始化函数实现
*/
//初始化全局变量
void setup_global(void) {
	//全局变量初始化
	global_init();
}
//初始化IO口
void setup_gpio(void) {
	//IO初始化
	io_init();
}
//初始化工作指示灯 初始化已在io_init中初始化
void setup_nled(void) {
	nled_off();			//工作指示灯关闭
}
//初始化蜂鸣器 初始化已在io_init中初始化
void setup_beep(void) {
	beep_off();			//关闭蜂鸣器
}			

//初始化串口1
void setup_uart1(void) {
	//串口1初始化
	uart1_init(115200);
	//uart1_close();
	uart1_open();
	//串口发送测试字符
	uart1_send_str((u8 *)"uart1 check ok!");
}
//初始化串口2
void setup_uart2(void) {
	//串口2初始化
	uart2_init(115200);
	//uart2_close();
	uart2_open();
	//串口发送测试字符
	uart2_send_str((u8 *)"uart2 check ok!");
}	
//初始化串口4
void setup_uart4(void) {
	//串口4初始化
	uart4_init(115200);
	//uart4_close();
	uart4_open();
	
	//串口发送测试字符
	uart4_send_str((u8 *)"uart4 check ok!");
}	
//初始化滴答时钟，1S增加一次systick_ms的值
void setup_systick(void) {
	//系统滴答时钟初始化	
	timer3_init();
}	


//初始化启动信号
void setup_start(void) {
	//蜂鸣器LED 名叫闪烁 示意系统启动
	beep_on();nled_on();mdelay(100);beep_off();nled_off();mdelay(100);
	beep_on();nled_on();mdelay(100);beep_off();nled_off();mdelay(100);
	beep_on();nled_on();mdelay(100);beep_off();nled_off();mdelay(100);
}	


//初始化总中断
void setup_interrupt(void) {
	//串口1设为高优先级
	IP = 0X10;
	//IP2 = 0X01;
	//总中断打开
	EA = 1;
}	

void setup_zx_servo(void) {//开机动作测试舵机
    static int index = 0, pwmv = 1500, timev = 0;
    index = 0; pwmv = 1700;timev = 200;
    sprintf(cmd_return, ">>>#%03dP%04dT%04d!", index, pwmv, timev);
    zx_uart_send_str(cmd_return);
    mdelay(1000);

    index = 0; pwmv = 1300;timev = 200;
    sprintf(cmd_return, ">>>#%03dP%04dT%04d!", index, pwmv, timev);
    zx_uart_send_str(cmd_return);
    mdelay(1000);

    index = 0; pwmv = 1500;timev = 200;
    sprintf(cmd_return, ">>>#%03dP%04dT%04d!", index, pwmv, timev);
    zx_uart_send_str(cmd_return);
    mdelay(1000);

    zx_uart_send_str("#000PULK!");mdelay(10);
    zx_uart_send_str("#000PULM!");
}
//--------------------------------------------------------------------------------


//--------------------------------------------------------------------------------
/*
	主循环函数实现
*/
//循环执行工作指示灯，500ms跳动一次
void loop_nled(void) {
	static u32 systick_ms_bak = 0;
	if(millis() - systick_ms_bak >= 500) {
		systick_ms_bak = millis();
		nled_switch();	
	}
}		
//串口数据接收处理
void loop_uart(void) {
	int index, pwmv;
	if(uart1_get_ok) {
		//测试发回去
		uart1_send_str(uart_receive_buf);
		
		if(uart1_mode == 1) {				//命令模式
			//uart1_send_str(">cmd");
		} else if(uart1_mode == 2) {		//单个舵机模式
			//uart1_send_str(">sig");
			if(uart_receive_buf[0] =='#' && uart_receive_buf[4] =='P' && uart_receive_buf[9] =='!') {
                index = (uart_receive_buf[1] - '0')*100 +  (uart_receive_buf[2] - '0')*10 +  (uart_receive_buf[3] - '0')*1;
                pwmv =  (uart_receive_buf[5] - '0')*1000 + (uart_receive_buf[6] - '0')*100 +  (uart_receive_buf[7] - '0')*10 +  (uart_receive_buf[8] - '0')*1;
                sprintf(cmd_return, "index = %03d  pwmv = %04d", index, pwmv);
                uart1_send_str(cmd_return);
            }
		} else if(uart1_mode == 3) {		//多个舵机模式
			//uart1_send_str(">group:");
			//总线下发
		} else if(uart1_mode == 4) {		//保存模式
			//uart1_send_str(">save");
			//uart1_send_str(uart_receive_buf);
		} 
		uart1_mode = 0;
		uart1_get_ok = 0;
		memset(uart_receive_buf, 0, sizeof(uart_receive_buf));
		//uart1_open();
	}

	return;
}

void loop_read(void) {
   static long systick_ms_bak = 0;

   //循环发送角度
   if(millis() - systick_ms_bak > 1000) {
      systick_ms_bak = millis();
      zx_uart_send_str("#000PRAD!");
   }
}




