#ifndef __ADC_H__
#define __ADC_H__


unsigned char adc_init(unsigned char ch);
unsigned short adc_read(unsigned char ch);



#endif


