#ifndef __DELAY_H__
#define __DELAY_H__

void delay(unsigned int t);
void udelay(unsigned int t);
void mdelay(unsigned int t);



#endif