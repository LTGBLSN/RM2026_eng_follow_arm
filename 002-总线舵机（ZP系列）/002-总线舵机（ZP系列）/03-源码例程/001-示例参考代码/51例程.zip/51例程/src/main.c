/*
单片机：STC15W4K61S4/IAP15W4K61S4 内部晶振：22.1184	
*/
#include "stc15.h"
#include <stdio.h>

#define FOSC 22118400L          //
#define BAUD 115200L            //

#define S2RI  0x01    			//
#define S2TI  0x02   			// 

#define ISPPROGRAM() ((void(code*)())0xF000)()

u8 busy2 = 0;
u32 uart_timeout = 0;

void uart1_init(void);
void uart1_send_byte(u8 dat);
void uart1_send_str(char *s);
void uart1_close(void);
void uart1_open(void);

void uart2_init(void);
void uart2_send_byte(u8 dat);
void uart2_send_str(char *s);
void uart2_close(void);
void uart2_open(void);

void zx_uart_send_str(char *s);
void delay_ms(unsigned int t);		//简单的延时

int id, pwm, time;
char cmd_return[100];//这里的cmd_return的字符长度要足够的大，根据舵机个数定，大小 = 15*个数+10

void main(void) {
	//串口1初始化
	uart1_init();
	//uart1_close();
	uart1_open();
	
	//串口2初始化
	uart2_init();
	//uart2_close();
	uart2_open();
    while (1) {
		uart1_send_str((u8 *)"#000P0500T1000!");	//串口1 让0号舵机旋转到0500的位置 舵机的位置范围 500~2500
		zx_uart_send_str((u8 *)"#000P0500T1000");	//总线口 让0号舵机旋转到0500的位置 舵机的位置范围 500~2500
		delay_ms(1000);						//延时1秒	
		uart1_send_str((u8 *)"#000P2500T1000!");	//串口1 让0号舵机旋转到2500的位置 舵机的位置范围 500~2500
		zx_uart_send_str((u8 *)"#000P2500T1000!");	//总线口 让0号舵机旋转到2500的位置 舵机的位置范围 500~2500
		delay_ms(1000);						//延时1秒	
		
		//0号舵机用 变量控制 单个舵机控制
		id = 0;
		time = 0;
		for(pwm=500;pwm<2500;pwm++) {
			sprintf(cmd_return, "#%03dT%04dT%04d!", id, pwm, time);
			uart1_send_str(cmd_return);
			zx_uart_send_str(cmd_return);
			delay_ms(1);						//延时1秒
		}
		
		//0号 1号 舵机用 变量控制 多个舵机控制 加{}
		id = 0;
		time = 0;
		for(pwm=500;pwm<2500;pwm++) {
			sprintf(cmd_return, "{#%03dT%04dT%04d!#%03dT%04dT%04d!}", id, pwm, time, id+1, pwm, time);
			uart1_send_str(cmd_return);
			zx_uart_send_str(cmd_return);
			delay_ms(1);						//延时1秒
		}
	}
}

void delay_ms(unsigned int t) {
	int t1;
	while(t--) {
		t1 = 3000;
		while(t1--);
	}
}

void uart1_init(void) {
	SCON |= 0x50;       //
	T2L = (65536 - (FOSC/4/BAUD));
	T2H = (65536 - (FOSC/4/BAUD))>>8;
	AUXR |= 0x15;       //
	PCON = 0;//0x7F;    //
	EA = 1;   
	ES = 1;             //	
}

void uart2_init(void) {
	S2CON = 0x50;         //
	T2L = (65536 - (FOSC/4/BAUD));    //
	T2H = (65536 - (FOSC/4/BAUD))>>8; //
	IE2 = 0x01;
	EA = 1; 
	P_SW2 |= 0x01;	//TX2 4.7 RX2 4.6	
}

void uart1_open(void) {
	ES = 1;
}

void uart1_close(void) {
	ES = 0;
}

void uart2_open(void) {
	//ES2 = 1;
	IE2 = 0x01; 
}

void uart2_close(void) {
	//ES2 = 0;
	IE2 = 0x00; 
}


/*----------------------------

----------------------------*/
void uart1_send_byte(u8 dat) {
    SBUF = dat;   
    while(TI == 0);   
    TI = 0; 
}

void uart2_send_byte(u8 dat) {
    S2BUF = dat;   
	while(!(S2CON & S2TI));
	S2CON &= ~S2TI; 
}

/*----------------------------

----------------------------*/
void uart1_send_str(char *s) {
    while (*s) {                  	//
        uart1_send_byte(*s++);         //
    }
}

void uart2_send_str(char *s) {
    while (*s) {                  		//
        uart2_send_byte(*s++);         //
    }
}

void zx_uart_send_str(char *s) {
    while (*s) {                  		//
        uart2_send_byte(*s++);         //
    }
}


/*----------------------------

串口中断函数

-----------------------------*/
void Uart() interrupt 4 using 1 {
	static u16 buf_index = 0;
	static u8 sbuf_bak;
	
    if (RI) {
		sbuf_bak = SBUF;
		RI = 0;                 
    }
	
//    if (TI) {
//        TI = 0;                 
//    }
}

void UART2_Int(void) interrupt  8 using 1
{
	static u16 buf_index = 0;
	static u8 sbuf_bak;
	if(S2CON&S2RI)		  		
	{   
		sbuf_bak = S2BUF;
		S2CON &= ~S2RI;
		
	}
	
//	if (S2CON&S2TI)// ½ÓÊÕµ½·¢ËÍÃüÁî
//	{
//		busy2 = 0;
//	}
}

